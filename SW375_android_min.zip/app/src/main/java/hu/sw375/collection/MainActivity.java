package hu.sw375.collection;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.content.ClipData;
import android.content.ActivityNotFoundException;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new AndroidShareBridge(), "AndroidShare");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                String[] acceptTypes = fileChooserParams != null
                        ? fileChooserParams.getAcceptTypes()
                        : null;

                String mimeType = "*/*";
                if (acceptTypes != null && acceptTypes.length > 0) {
                    for (String type : acceptTypes) {
                        if (type != null && !type.trim().isEmpty()) {
                            mimeType = type;
                            break;
                        }
                    }
                }

                // Some WebView versions report ".json" or extensions instead of MIME types.
                if (mimeType.startsWith(".")) {
                    if (".json".equalsIgnoreCase(mimeType)) {
                        mimeType = "application/json";
                    } else {
                        mimeType = "*/*";
                    }
                }

                intent.setType(mimeType);

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception ex) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }


    private class AndroidShareBridge {
        private static final String RECIPIENT = "corvellus92@gmail.com";

        @JavascriptInterface
        public void sendMasterSuggestion(String json, String subject, String body) {
            runOnUiThread(() -> {
                try {
                    File shareDir = new File(getCacheDir(), "shared");
                    if (!shareDir.exists() && !shareDir.mkdirs()) {
                        throw new Exception("Could not create share directory");
                    }

                    String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                    String filename = "SW375_Community_Contribution_" + stamp + ".json";
                    File out = new File(shareDir, filename);

                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        fos.write(json.getBytes(StandardCharsets.UTF_8));
                    }

                    Uri attachment = new Uri.Builder()
                            .scheme("content")
                            .authority(getPackageName() + ".share")
                            .appendPath(filename)
                            .build();

                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("application/json");
                    send.putExtra(Intent.EXTRA_EMAIL, new String[]{RECIPIENT});
                    send.putExtra(Intent.EXTRA_SUBJECT,
                            subject == null || subject.trim().isEmpty()
                                    ? "3.75 Collection – Master Update Suggestion"
                                    : subject);
                    send.putExtra(Intent.EXTRA_TEXT, body == null ? "" : body);
                    send.putExtra(Intent.EXTRA_STREAM, attachment);
                    send.setClipData(ClipData.newRawUri("3.75 Collection suggestion", attachment));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                    startActivity(Intent.createChooser(send, "Send Master Suggestion"));
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(MainActivity.this,
                            "No email/share application found.", Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this,
                            "Could not prepare suggestion email: " + ex.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;

            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }

            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
