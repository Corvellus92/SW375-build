package hu.sw375.collection;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ShareFileProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    private File resolveFile(Uri uri) throws FileNotFoundException {
        if (getContext() == null) {
            throw new FileNotFoundException("No context");
        }

        String filename = uri.getLastPathSegment();
        if (filename == null || filename.isEmpty() ||
                filename.contains("/") || filename.contains("\\") ||
                filename.contains("..")) {
            throw new FileNotFoundException("Invalid filename");
        }

        File base = new File(getContext().getCacheDir(), "shared");
        File file = new File(base, filename);

        try {
            String basePath = base.getCanonicalPath() + File.separator;
            String filePath = file.getCanonicalPath();
            if (!filePath.startsWith(basePath)) {
                throw new FileNotFoundException("Invalid path");
            }
        } catch (IOException e) {
            throw new FileNotFoundException("Invalid path");
        }

        if (!file.exists() || !file.isFile()) {
            throw new FileNotFoundException("File not found");
        }
        return file;
    }

    @Override
    public String getType(Uri uri) {
        return "application/json";
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) {
            throw new FileNotFoundException("Read only");
        }
        return ParcelFileDescriptor.open(resolveFile(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        try {
            File file = resolveFile(uri);
            String[] cols = projection != null ? projection :
                    new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};

            MatrixCursor cursor = new MatrixCursor(cols);
            MatrixCursor.RowBuilder row = cursor.newRow();
            for (String col : cols) {
                if (OpenableColumns.DISPLAY_NAME.equals(col)) {
                    row.add(file.getName());
                } else if (OpenableColumns.SIZE.equals(col)) {
                    row.add(file.length());
                } else {
                    row.add(null);
                }
            }
            return cursor;
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) { return 0; }

    @Override
    public Uri insert(Uri uri, ContentValues values) { return null; }
}
